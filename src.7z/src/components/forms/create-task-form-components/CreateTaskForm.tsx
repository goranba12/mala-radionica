import { Form, Input, DatePicker, Switch, Space, message, Typography, Col } from 'antd'
import { useEffect, useState } from 'react'
import { useGlobalContext } from '../../GlobalContextProvider'
import TaskService from '@/services/TaskService'
import { ITaskResponse } from '@/model/response/ITaskResponse'
import dayjs from 'dayjs'
import { 
  LeftOutlined,
  CheckOutlined,
  EditOutlined,
  CalendarOutlined,
  ClockCircleOutlined
} from '@ant-design/icons'

const CreateTaskForm = () => {
  const {
    currentPage,
    setCurrentPage,
    Contact,
    setFormTitle,
    setCurrentTask,
    setModalIsOpen,
  } = useGlobalContext()

  useEffect(() => {
    setFormTitle('Detalji posla')
  }, [])

  const [TaskForm] = Form.useForm<ITaskResponse>()
  const [isFinished, setIsFinished] = useState(false)
  const [animating, setAnimating] = useState(false)

  useEffect(() => {
    setAnimating(true)
    const timer = setTimeout(() => setAnimating(false), 300)
    return () => clearTimeout(timer)
  }, [isFinished])

  const onClickHandler = () => {
    TaskForm.validateFields().then((values) => {
      const fullData = {
        ...values,
        contact_id: Contact?.id ?? 0,
      }

      TaskService.createTask(fullData)
        .then((response) => {
          console.log(fullData, 'data')
          console.log(response, 'response')
          message.success('Posao uspesno kreiran!')
          setCurrentTask({
            task_id: response.data.id,
            end_date: values.end_date,
          })
          setCurrentPage(0)
        })
        .then(() => {
          isFinished ? setCurrentPage(currentPage + 1) : setModalIsOpen(false)
        })
        .catch((error) => {
          console.error('Error creating contact:', error)
          message.error('Greška prilikom kreiranja unosa. Kontaktirajte administratora.')
        })
    })
  }

  return (
    <Form
      id="glowic"
      form={TaskForm}
      layout="vertical"
      className="bg-white opacity-90"
      initialValues={{ creation_date: dayjs(Date.now()), end_date: dayjs(Date.now()) }}
    >
      <Typography className="font-bold text-xl mb-12 text-center">{'Posao za: ' + Contact?.fullName}</Typography>

      {/* Job Name */}
      <Form.Item 
        label="Naslov posla:" 
        name="job_name" 
        rules={[{ required: false, message: 'Popuni naziv posla!' }]}
      >
        <Input prefix={<EditOutlined />} />
      </Form.Item>

      {/* Job Description */}
      <Form.Item label="Detalji posla:" name="job_description" rules={[{ required: false }]}>
        <Input.TextArea />
      </Form.Item>

      {/* Date Section */}
      <div className="flex flex-row">
        <Col span={8}>
          <Form.Item label="Zapocet:" name="creation_date" className="mt-5">
            <Space direction="vertical">
              <DatePicker
                id="creation_date"
                showTime={{ minuteStep: 15 }}
                format="MMM-DD HH:mm"
                defaultValue={dayjs(TaskForm.getFieldValue('creation_date'))}
                onChange={(date) => TaskForm.setFieldValue('creation_date', date)}
                suffixIcon={<ClockCircleOutlined />}
              />
            </Space>
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label={!isFinished ? 'Aktivan' : 'Status:'} className="ml-6 mt-5">
            <Switch 
              checked={isFinished} 
              onChange={() => setIsFinished(!isFinished)} 
              className="mr-10"
              checkedChildren={<CheckOutlined />}
              unCheckedChildren={<CheckOutlined />}
            />
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="Zavrsen" name="end_date" className="mt-5">
            <DatePicker
              showTime={{ minuteStep: 15 }}
              format="MMM-DD HH:mm"
              defaultOpenValue={dayjs(TaskForm.getFieldValue('end_date'))}
              defaultValue={dayjs(TaskForm.getFieldValue('end_date'))}
              onChange={(date) => TaskForm.setFieldValue('end_date', date)}
              disabled={!isFinished}
              suffixIcon={<CalendarOutlined />}
            />
          </Form.Item>
        </Col>
      </div>

      <div className="flex flex-row justify-between mt-5">
        <div 
          onClick={() => setCurrentPage(currentPage - 1)} 
          style={{ cursor: "pointer" }}
          className="flex flex-col items-center"
        >
          <LeftOutlined
            style={{
              fontSize: '32px',
              color: '#fa8c16',
              transform: "scale(1.5, 1.5)",
              transformOrigin: "center",
            }}
          />
          <span className="text-sm mt-1">Nazad</span>
        </div>

        <div 
          onClick={onClickHandler} 
          style={{ cursor: "pointer" }}
          className="flex flex-col items-center"
        >
          {isFinished ? (
            <>
              <CheckOutlined
                style={{
                  fontSize: '32px',
                  color: '#52c41a',
                  transform: "scale(1.5, 1.5)",
                  transformOrigin: "center",
                }}
              />
              <span className="text-sm mt-1">Završi</span>
            </>
          ) : (
            <>
              <EditOutlined
                style={{
                  fontSize: '32px',
                  color: '#1890ff',
                  transform: "scale(1.5, 1.5)",
                  transformOrigin: "center",
                }}
              />
              <span className="text-sm mt-1">Sačuvaj</span>
            </>
          )}
        </div>
      </div>
    </Form>
  )
}

export default CreateTaskForm