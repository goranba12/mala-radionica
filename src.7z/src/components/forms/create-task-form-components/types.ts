export interface VLI {
  value: string
  label: string
  id: number
}
