import { Button, Form, Input, Select, Typography, Card, Divider, Row, Col } from 'antd';
import { IProduct } from '@/model/response/IProductResponse';
import { useEffect, useState } from 'react';
import { fetchUniqueManufacturers, onHandleSubmit } from './actions';
import { useGlobalContext } from '@/components/GlobalContextProvider';

export const FormularZaUnosProizvoda = () => {
  // Naslov
  const { setHeaderTitle } = useGlobalContext();
  useEffect(() => {
    setHeaderTitle('Unos novog proizvoda');
  }, []);
  
  const [form] = Form.useForm<IProduct>();
  const [proizvodjaci, setProizvodjaci] = useState<string[]>([]);
  const [ucitavaSe, setUcitavaSe] = useState(false);

  useEffect(() => {
    const ucitajProizvodjace = async () => {
      setUcitavaSe(true);
      try {
        const proizvodjaci = await fetchUniqueManufacturers();
        setProizvodjaci(proizvodjaci);
      } catch (error) {
        console.error('Greška pri učitavanju proizvođača:', error);
      } finally {
        setUcitavaSe(false);
      }
    };

    ucitajProizvodjace();
  }, []);

  const potvrdiFormular = async () => {
    try {
      setUcitavaSe(true);
      await onHandleSubmit(form);
    } catch (error) {
      console.error('Greška pri slanju:', error);
    } finally {
      setUcitavaSe(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gray-50">
      <Card 
        className="w-full max-w-2xl shadow-lg"
        title={
          <Typography.Title level={3} className="text-center mb-0">
            Unos podataka o proizvodu
          </Typography.Title>
        }
      >
        <Form
          form={form}
          layout="vertical"
          requiredMark="optional"
          className="w-full"
        >
          <Divider orientation="left" plain>Osnovne informacije</Divider>
          
          <Form.Item
            name="name"
            label="Naziv proizvoda"
            rules={[{ required: true, message: 'Unesite naziv proizvoda' }]}
          >
            <Input placeholder="Unesite naziv proizvoda" size="large" />
          </Form.Item>

          <Row gutter={16}>
            <Col xs={24} md={12}>
              <Form.Item
                name="manufacturer"
                label="Proizvođač"
                rules={[{ required: true, message: 'Izaberite proizvođača' }]}
              >
                <Select
                  size="large"
                  placeholder="Izaberite proizvođača"
                  showSearch
                  loading={ucitavaSe}
                  filterOption={(input, option) =>
                    (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                  }
                  options={proizvodjaci.map(p => ({
                    value: p,
                    label: p,
                  }))}
                />
              </Form.Item>
            </Col>
            <Col xs={24} md={12}>
              <Form.Item
                name="model"
                label="Model"
              >
                <Input placeholder="Unesite model" size="large" />
              </Form.Item>
            </Col>
          </Row>

          <Divider orientation="left" plain>Cena i zaliha</Divider>
          
          <Row gutter={16}>
            <Col xs={24} md={12}>
              <Form.Item
                name="price"
                label="Cena"
              >
                <Input 
                  type="number" 
                  addonAfter="RSD" 
                  size="large" 
                  placeholder="0.00" 
                />
              </Form.Item>
            </Col>
            <Col xs={24} md={12}>
              <Form.Item
                name="quantity"
                label="Količina na zalihama"
              >
                <Input 
                  type="number" 
                  size="large" 
                  placeholder="0" 
                />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            name="SKU"
            label="SKU (Jedinstveni identifikator)"
            tooltip="Jedinstveni kod za praćenje zaliha"
          >
            <Input placeholder="Unesite SKU" size="large" />
          </Form.Item>

          <Divider />

          <Form.Item className="text-right">
            <Button 
              type="default" 
              size="large" 
              className="mr-4"
              onClick={() => form.resetFields()}
            >
              Poništi
            </Button>
            <Button 
              type="primary" 
              size="large" 
              loading={ucitavaSe}
              onClick={potvrdiFormular}
            >
              Sačuvaj proizvod
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default FormularZaUnosProizvoda;