import { useState, useEffect } from 'react';
import { ITaskResponse } from '@/model/response/ITaskResponse';
import { Table, Input, Popconfirm, message, Modal, Form, Space, Button, Tooltip, Typography } from 'antd';
import { DeleteOutlined, EditOutlined, FileDoneOutlined } from '@ant-design/icons';
import { IContact } from '@/model/response/IContactResponse';
import { useGetAllTasks, handleEdit, handleDelete, handleSave } from './actions';
import { useGlobalContext } from '@/components/GlobalContextProvider';
import CreateBillForm from '@/components/forms/create-task-form-components/CreateBillForm';
import { contact_firstName, contact_lastName, contact_phoneNumber, taskName, creation_date } from './constants';

export const TasksList = () => {
  const { setContextContact, setCurrentTask, setHeaderTitle, setCurrentPage } = useGlobalContext();

  useEffect(() => {
    setHeaderTitle('Aktivni poslovi');
  }, []);

  const { tasks } = useGetAllTasks();
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredTasks, setFilteredTasks] = useState<ITaskResponse[]>(tasks || []);
  const [editingTask, setEditingTask] = useState<ITaskResponse | null>(null);
  const [isEditModalOpen, setEditModalOpen] = useState(false);
  const [billModalOpen, setBillModalOpen] = useState(false);
  const [FormTaskList] = Form.useForm<ITaskResponse>();

  useEffect(() => {
    setFilteredTasks(
      tasks?.filter((task) => {
        const searchText = searchTerm.toLowerCase();
        return (
          task.job_name?.toLowerCase().includes(searchText) ||
          task.job_description?.toLowerCase().includes(searchText) ||
          task.firstName?.toLowerCase().includes(searchText) ||
          task.lastName?.toLowerCase().includes(searchText)
        );
      }) || []
    );
  }, [searchTerm, tasks]);

  const columns = [
    contact_firstName,
    contact_lastName,
    contact_phoneNumber,
    taskName,
    creation_date,
    {
      title: 'Akcije',
      key: 'action',
      align: 'center',
      render: (record: ITaskResponse) => (
        <Space size="middle">
          <Tooltip title="Izmeni">
            <Button
              style={{ background: '#f5f5f5', borderColor: '#d9d9d9', color: '#595959' }}
              onClick={() => handleEdit(record, setEditingTask, FormTaskList, setEditModalOpen)}
            >
              <EditOutlined />
            </Button>
          </Tooltip>
          <Popconfirm
            title="Da li ste sigurni da želite izbrisati ovaj posao?"
            onConfirm={() => handleDelete(record.id, filteredTasks, setFilteredTasks)}
            onCancel={() => message.warning('Brisanje posla otkazano!')}
            okText="Da"
            cancelText="Ne"
          >
            <Tooltip title="Obriši">
              <Button danger style={{ background: '#ff4d4f', borderColor: '#ff4d4f' }}>
                <DeleteOutlined style={{ color: 'white' }} />
              </Button>
            </Tooltip>
          </Popconfirm>
          <Tooltip title="Naplata">
            <Button
              style={{ background: '#52c41a', borderColor: '#52c41a', color: 'white' }}
              onClick={() => {
                setContextContact({ id: record.contact_id, fullName: `${record.firstName} ${record.lastName}` } as IContact);
                setCurrentTask({ task_id: record.id, task_name: record.job_name });
                setBillModalOpen(true);
              }}
            >
              <FileDoneOutlined />
            </Button>
          </Tooltip>
        </Space>
      ),
    },
  ];
  

  return (
    <div className="flex flex-col h-full overflow-y-auto p-6 bg-white text-gray-900">
      <Modal open={isEditModalOpen} onCancel={() => setEditModalOpen(false)} footer={null} title="Izmeni posao">
        <Form form={FormTaskList} layout="vertical">
          <Form.Item label="Naziv posla" name="job_name" rules={[{ required: true, message: 'Unesi naziv posla' }]}> 
            <Input />
          </Form.Item>
          <Form.Item label="Detalji posla" name="job_description">
            <Input.TextArea rows={4} />
          </Form.Item>
          <Form.Item>
            <Space>
              <Button type="primary" onClick={() => handleSave(FormTaskList, editingTask, filteredTasks, setFilteredTasks, setEditModalOpen)}>Sačuvaj</Button>
              <Button onClick={() => setEditModalOpen(false)}>Otkaži</Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>
      <Modal open={billModalOpen} onCancel={() => setBillModalOpen(false)} footer={null}>
        <CreateBillForm callback={() => { setBillModalOpen(false); setCurrentPage(0); }} />
      </Modal>
      <Input placeholder="Pretraži aktivne poslove" onChange={(e) => setSearchTerm(e.target.value)} className="mb-4 p-2 border border-gray-300 rounded-md shadow-sm" />
      <Table columns={columns} dataSource={filteredTasks} rowKey="id" pagination={{ pageSize: 11 }} />
    </div>
  );
};

export default TasksList;