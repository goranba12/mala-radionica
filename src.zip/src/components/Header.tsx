import {
  ContactsOutlined,
  DatabaseOutlined,
  FileAddOutlined,
  HomeOutlined,
  ProductOutlined,
  ToolOutlined,
} from '@ant-design/icons';
import { Tooltip, Typography, Button } from 'antd';
import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useGlobalContext } from './GlobalContextProvider';

const Header = () => {
  const { headerTitle, setHeaderTitle, formTitleString } = useGlobalContext();
  const [showIframe, setShowIframe] = useState(false);
  const location = useLocation();
  const [activeLink, setActiveLink] = useState('');

  useEffect(() => {
    setHeaderTitle(formTitleString);
    setActiveLink(location.pathname);
  }, [formTitleString, location.pathname]);

  const handleExternalLinkClick = (e) => {
    e.preventDefault();
    setShowIframe(true);
  };

  const closeIframe = () => {
    setShowIframe(false);
  };

  // Lista navigacionih linkova za čistiji kod
  const navLinks = [
    {
      path: "/Tasks",
      icon: <ToolOutlined />,
      title: "Aktivni poslovi",
      key: "tasks"
    },
    {
      path: "/ProductList",
      icon: <ProductOutlined />,
      title: "Lista proizvoda",
      key: "products"
    },
    {
      path: "/ContactsList",
      icon: <ContactsOutlined />,
      title: "Lista kontakta",
      key: "contacts"
    },
    {
      path: "/Bills",
      icon: <DatabaseOutlined />,
      title: "Završeni poslovi",
      key: "bills"
    }
  ];

  return (
    <>
  <header className="px-4 lg:px-6 p-7 h-16 flex items-center bg-white opacity-90 text-white" id="glowic">        {/* Logo ili naslov aplikacije */}
        <div className="flex items-center">
          <Typography.Title 
            level={4} 
            className="m-0 text-blue-600 hidden md:block"
            style={{ fontWeight: 600 }}
          >
            {headerTitle}
          </Typography.Title>
        </div>

        {/* Glavna navigacija */}
        <nav className="flex flex-1 justify-center">
          <div className="flex items-center space-x-2 sm:space-x-6">
            {navLinks.map((link) => (
              <Tooltip title={link.title} key={link.key}>
                <Link
                  to={link.path}
                  className={`flex items-center justify-center p-2 rounded-md transition-all ${
                    activeLink === link.path
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-500 hover:text-blue-500 hover:bg-blue-50'
                  }`}
                >
                  <span className="text-lg">{link.icon}</span>
                  <span className="ml-2 text-sm font-medium hidden sm:inline">
                    {link.title}
                  </span>
                </Link>
              </Tooltip>
            ))}
          </div>
        </nav>

        {/* Dodatne akcije (desna strana) */}
        <div className="flex items-center space-x-4">
          {/* Možete dodati korisničke akcije ovde */}
        </div>
      </header>

  
      
    </>
  );
};

export default Header;