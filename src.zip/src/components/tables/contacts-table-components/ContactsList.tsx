import React, { useState, useEffect } from 'react'
import { Table, Input, Popconfirm, message, Modal, Form, Space, Button, Tooltip, Typography } from 'antd'
import { IContactsResponse } from '@/model/response/IContactResponse'
import { useGlobalContext } from '../../GlobalContextProvider'
import { DeleteOutlined, EditOutlined, SearchOutlined, UserOutlined } from '@ant-design/icons'
import { contact_city, contact_firstName, contact_lastName, contact_phoneNumber } from './constants'
import { handleEdit, handleDelete, handleSave, useGetAllContacts } from './actions'

const ContactsList: React.FC = () => {
  const { setHeaderTitle } = useGlobalContext()
  useEffect(() => {
    setHeaderTitle('Kontakti')
  }, [])

  const { contacts } = useGetAllContacts()
  const [searchTerm, setSearchTerm] = useState('')
  const [filteredContacts, setFilteredContacts] = useState<IContactsResponse[]>([])
  const [editingContact, setEditingContact] = useState<IContactsResponse>({} as IContactsResponse)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [FormContactList] = Form.useForm<IContactsResponse>()

  useEffect(() => {
    const filtered = contacts.filter((contact) => {
      const searchText = searchTerm.toLowerCase()
      return (
        contact.firstName?.toLowerCase().includes(searchText) ||
        contact.lastName?.toLowerCase().includes(searchText) ||
        contact.city?.toLowerCase().includes(searchText) ||
        contact.phoneNumber?.toLowerCase().includes(searchText)
      )
    })
    setFilteredContacts(filtered)
  }, [searchTerm, contacts])

  const actions = {
    title: 'Akcije',
    align: 'center',
    key: 'action',
    render: (record: IContactsResponse) => (
      <Space size="middle" className="flex justify-center">
        <Tooltip title="Izmeni">
          <Button
            type="text"
            icon={<EditOutlined style={{ color: '#1890ff' }} />}
            onClick={() => handleEdit(record, setEditingContact, FormContactList, setIsModalOpen)}
          />
        </Tooltip>
        <Popconfirm
          title="Da li ste sigurni da želite izbrisati ovaj kontakt?"
          onConfirm={() => handleDelete(record.id, filteredContacts, setFilteredContacts)}
          onCancel={() => message.info('Brisanje otkazano')}
          okText="Da"
          cancelText="Ne"
          okButtonProps={{ className: 'bg-blue-500 hover:bg-blue-600' }}
        >
          <Tooltip title="Obriši">
            <Button type="text" danger icon={<DeleteOutlined />} />
          </Tooltip>
        </Popconfirm>
      </Space>
    ),
  }

  const columns = [contact_firstName, contact_lastName, contact_city, contact_phoneNumber, actions]

  return (
    <div className="bg-white p-6 shadow-sm h-full flex flex-col">
      <div className="bg-white p-6 shadow-sm h-full flex flex-col">
        <Typography.Title level={3} className="m-0">
          Lista Kontakata
        </Typography.Title>
        <Input.Search
          size="large"
          placeholder="Pretraži kontakte..."
          prefix={<SearchOutlined />}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-1/3"
          allowClear
        />
      </div>

      <Table
        size="middle"
        columns={columns}
        dataSource={filteredContacts}
        pagination={{ 
          pageSize: 15,
          showSizeChanger: false,
          className: 'px-4'
        }}
        rowKey="id"
        className="border rounded-lg"
        rowClassName="hover:bg-gray-50"
      />

      <Modal
        title={
          <div className="flex items-center">
            <UserOutlined className="mr-2 text-blue-500" />
            <span>Uredi kontakt</span>
          </div>
        }
        open={isModalOpen}
        onOk={() => handleSave(FormContactList, editingContact, filteredContacts, setFilteredContacts, setIsModalOpen)}
        onCancel={() => setIsModalOpen(false)}
        okText="Sačuvaj"
        cancelText="Odustani"
        okButtonProps={{ className: 'bg-blue-500 hover:bg-blue-600' }}
      >
        <Form form={FormContactList} layout="vertical" className="mt-6">
          <Form.Item
            label="Ime"
            name="firstName"
            rules={[{ required: true, message: 'Unesite ime' }]}
          >
            <Input placeholder="Unesite ime" />
          </Form.Item>
          <Form.Item label="Prezime" name="lastName">
            <Input placeholder="Unesite prezime" />
          </Form.Item>
          <Form.Item label="Grad" name="city">
            <Input placeholder="Unesite grad" />
          </Form.Item>
          <Form.Item 
            label="Telefon" 
            name="phoneNumber"
            rules={[{ pattern: /^\d+$/, message: 'Unesite validan broj telefona' }]}
          >
            <Input placeholder="Unesite broj telefona" />
          </Form.Item>
          <Form.Item label="Adresa" name="address">
            <Input placeholder="Unesite adresu" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  )
}

export default ContactsList