import { Form, Switch, InputNumber, Typography, message, DatePicker } from 'antd'
import { useEffect, useState } from 'react'
import BillService from '@/services/BillService'
import { IBillResponse } from '@/model/response/IBillResponse'
import dayjs from 'dayjs'
import moment from 'moment'
import { useGlobalContext } from '../../GlobalContextProvider'
import SelectProductsComponent from '../../SelectProductsComponent'
import { 
  LeftOutlined,
  CheckOutlined,
  DollarOutlined,
  MoneyCollectOutlined,
  ToolOutlined
} from '@ant-design/icons'

const CreateBillForm = ({ callback }: { callback: () => void }) => {
  const [rows, setRows] = useState<{ product: any; quantity: number }[]>([])
  const { Contact, currentTask, setCurrentPage, currentPage } = useGlobalContext()
  const [FormBillCreate] = Form.useForm<IBillResponse>()
  const [isPaid, setIsPaid] = useState(false)
  const [animating, setAnimating] = useState(false)

  useEffect(() => {
    setAnimating(true)
    const timer = setTimeout(() => setAnimating(false), 300)
    return () => clearTimeout(timer)
  }, [isPaid])

  const addRow = () => {
    setRows([...rows, { product: null, quantity: 1 }])
  }

  const removeRow = () => {
    if (rows.length > 0) {
      const newRows = [...rows]
      newRows.pop()
      setRows(newRows)
      FormBillCreate.setFieldsValue({
        products_used: newRows,
      })
    }
  }

  const submitLogic = () => {
    FormBillCreate.validateFields().then(async (values) => {
      const billed_product = values.products_used?.map((item) => ({
        product_id: item.product?.id,
        name: item.product?.name,
        manufacturer: item.product?.manufacturer,
        quantity: Number(item.quantity),
        price: Number(item.product?.price),
      }))

      const parts_cost = billed_product?.reduce((acc, item) => acc + item.quantity * item.price, 0)
      const total_cost = parts_cost + values.labor_cost

      const updatedValues = {
        ...values,
        products_used: billed_product,
        contact_id: Contact?.id,
        job_id: currentTask.task_id,
        parts_cost,
        total_cost,
      }

      BillService.createBill(updatedValues as IBillResponse)
        .then(() => {
          values.products_used && BillService.productQUpdate(billed_product)
          message.success('Račun je uspješno kreiran!')
          FormBillCreate.resetFields()
          setCurrentPage(0)
          callback?.()
        })
        .catch((error) => {
          console.error('Error creating bill:', error)
          message.error('Došlo je do greške, kontaktirajte administratora.')
        })
    })
  }

  return (
    <Form
      id="glowic"
      className="bg-white opacity-90"
      form={FormBillCreate}
      layout="vertical"
      onFinish={submitLogic}
      initialValues={{
        paid: false,
        end_date: currentTask.end_date ? dayjs(currentTask.end_date) : dayjs(moment().toDate()),
        quantity: 1,
        labor_cost: 0,
      }}
    >
      <Typography className="font-bold text-xl mb-8 text-center">
        {'Naplata za: ' + Contact?.fullName}
      </Typography>

      <div className="flex justify-between items-center mb-6">
        <Form.Item
          label="Cena usluge"
          name="labor_cost"
          rules={[{ required: true, message: 'Cena usluge je obavezna!' }]}
          className="w-full"
        >
          <InputNumber
            suffix="RSD"
            style={{ width: '100%' }}
            min={0}
            step={100}
            prefix={<ToolOutlined />}
            className="rounded-md border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </Form.Item>

        <Form.Item
          label={isPaid ? 'Izmireno' : 'Neizmireno'}
          name="paid"
          valuePropName="checked"
          className="ml-4"
        >
          <Switch 
            checked={isPaid} 
            onChange={() => setIsPaid(!isPaid)}
            checkedChildren={<CheckOutlined />}
            unCheckedChildren={<CheckOutlined />}
          />
        </Form.Item>
      </div>

      <SelectProductsComponent
        form={FormBillCreate}
        rows={rows}
        addRow={addRow}
        removeRow={removeRow}
        setRows={setRows}
      />

      <Form.Item label="Datum plaćanja:" name="end_date" className="mb-4">
        <DatePicker
          showTime={{ minuteStep: 15 }}
          format="MMM-DD HH:mm"
          className="rounded-md border border-gray-300 py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          suffixIcon={<CheckOutlined />}
        />
      </Form.Item>

      <div className="flex flex-row justify-between mt-8">
        <div 
          onClick={() => setCurrentPage(currentPage - 1)}
          style={{ cursor: "pointer" }}
          className="flex flex-col items-center"
        >
          <LeftOutlined
            style={{
              fontSize: '32px',
              color: '#fa8c16',
              transform: "scale(1.5, 1.5)",
              transformOrigin: "center",
            }}
          />
          <span className="text-sm mt-1">Nazad</span>
        </div>

        <div 
          onClick={submitLogic}
          style={{ cursor: "pointer" }}
          className="flex flex-col items-center"
        >
          {isPaid ? (
            <>
              <MoneyCollectOutlined
                style={{
                  fontSize: '32px',
                  color: '#52c41a',
                  transform: "scale(1.5, 1.5)",
                  transformOrigin: "center",
                }}
              />
              <span className="text-sm mt-1">Završi</span>
            </>
          ) : (
            <>
              <DollarOutlined
                style={{
                  fontSize: '32px',
                  color: '#1890ff',
                  transform: "scale(1.5, 1.5)",
                  transformOrigin: "center",
                }}
              />
              <span className="text-sm mt-1">Sačuvaj</span>
            </>
          )}
        </div>
      </div>
    </Form>
  )
}

export default CreateBillForm