//axios server port:3000
//mySQL server :3306
//React node server port :5173

export const baseUrl = 'http://192.168.8.157:3000'
